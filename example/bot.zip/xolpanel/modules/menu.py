from xolpanel import *

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline("[ Ssh Menu ]","ssh"),
Button.inline("[ Trial SSH ]","trial-ssh")],
[Button.inline("[ Setting Menu ]","setting"),
Button.inline("[ Back To Menu ]","/start")],
[Button.url("[ Admin ]","https://t.me/fv_,stores"),
Button.url("[ Telegram Group ]","https://t.me/fv_storeid")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply("Akses Ditolak")
	elif val == "true":
		msg = f"""
━━━━━━━━━━━━━━━━
 ⟨ Admin Panel Menu ⟩
━━━━━━━━━━━━━━━━
» 🧊Bot Version: `v1.0`
» 🧊Bot By: `@fv_stores`
━━━━━━━━━━━━━━━━
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)
